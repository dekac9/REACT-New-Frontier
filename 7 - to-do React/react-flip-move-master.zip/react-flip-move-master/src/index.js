// @flow
/**
 * React Flip Move
 * (c) 2016-present Joshua Comeau
 */
import FlipMove from './FlipMove';

export default FlipMove;
